<?php
// Establish a connection to the SQL database
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "teacher";

$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Retrieve user input from login form
$id = $_POST["id"];
$password = $_POST["password"];
$login_option = $_POST["login_option"];

// Query the corresponding SQL table for the user's id and password
if ($login_option == "teacher") {
    $sql = "SELECT * FROM teacher WHERE id = '$id' AND password = '$password'";
} elseif ($login_option == "student") {
    $sql = "SELECT * FROM student WHERE id = '$id' AND password = '$password'";
}

$result = $conn->query($sql);

// Check if a match is found
if ($result->num_rows > 0) {
    // Start a session and redirect the user to their dashboard or homepage
    session_start();
    $_SESSION["id"] = $id;
    if ($login_option == "teacher")
    {
        header("Location: teacher.html"); // replace with the actual URL of the dashboard
    }elseif ($login_option == "student"){
        header("Location: student.html"); // replace with the actual URL of the dashboard
    } 
    exit();
} else {
    // Display an error message and prompt the user to try again
    echo "Invalid login credentials. Please try again.";
}

$conn->close();
?>
