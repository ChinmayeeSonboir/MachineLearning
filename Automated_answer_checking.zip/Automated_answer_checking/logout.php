<?php
// Start the session
session_start();

// Destroy the session data and redirect the user to the login page
session_destroy();
header("Location: front.html"); // replace with the actual URL of the login page
exit();
?>
