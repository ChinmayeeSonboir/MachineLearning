with open('input.txt', 'r') as input_file, open('output.txt', 'w') as output_file:
    previous_line_start = None
    for line in input_file:
        if line[0].isdigit() and line[1] == ')':
            previous_line_start = line.strip()
            output_file.write(previous_line_start + '\n')
        elif previous_line_start is not None:
            if not line[0].isdigit() or (line[0].isdigit() and line[1] != ')'):
                output_file.write(previous_line_start + line.strip())
                previous_line_start = None
            else:
                output_file.write(previous_line_start + '\n')
                previous_line_start = line.strip()
        else:
            output_file.write(line)
