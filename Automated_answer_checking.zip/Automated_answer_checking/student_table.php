<?php
// Retrieve the user's name and paper key from the form data
$name = $_POST['username'];
$key = $_POST['key'];

// Connect to the SQL database
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "teacher";
$conn = new mysqli($servername, $username, $password, $dbname);

// Check if the uploaded file was successful and retrieve the file data
if ($_FILES['file']['error'] === UPLOAD_ERR_OK) {
    $temp_file = $_FILES['file']['tmp_name'];
    $filename = $_FILES['file']['name'];
    $file_extension = pathinfo($filename, PATHINFO_EXTENSION);
    $new_filename = $name . '.' . $file_extension;
    $uploads_dir = __DIR__ . '/uploads/'; // Store files in the "uploads" subdirectory of the current script's directory
    $file_path = $uploads_dir . $new_filename;

    // Move the uploaded file to the uploads directory
    move_uploaded_file($temp_file, $file_path);



    // Check if the CSV file exists
    $csv_file = $uploads_dir . $key . '.csv';
    if (file_exists($csv_file)) {
        // Call the Python script with both file paths as arguments
        $command = 'python score.py ' . escapeshellarg($csv_file) . ' ' . escapeshellarg($file_path);
        // $command = 'python score.py ' . escapeshellarg($uploads_dir . 'science.csv') . ' ' . escapeshellarg($uploads_dir . 'ayush.txt');
        // echo $file_path;
        // echo $csv_file;
        // $output = exec($command);
        // $s = intval(trim($output));
        // echo $s; 


        $output = shell_exec($command);
        // Write the output to a log file
        $log_file =  $uploads_dir . $name . '_score.txt';
        file_put_contents($log_file, $output);
        // Display the output to the user

        $file = $uploads_dir . $name . '_score.txt'; // replace with the path to your file
        $filename =  $name . '_score.txt'; // replace with the name of your file

        header('Content-Type: application/octet-stream');
        header('Content-Disposition: attachment; filename="' . $filename . '"'); 
        header('Content-Length: ' . filesize($file));

        // // echo $output; 

        readfile($file);

        // // Insert the user's name and file path into the key_students table
        $stmt = $conn->prepare("INSERT INTO ".$key."_students (name, paper) VALUES (?, ?)");
        $stmt->bind_param("ss", $name, $file_path);
        $stmt->execute();
        exit;

    // // Display a success message to the user
    // echo "File uploaded successfully!";
    } else {
        echo "Invalid key";
    }

    // // // Insert the user's name and file path into the key_students table
    // $stmt = $conn->prepare("INSERT INTO ".$key."_students (name, paper) VALUES (?, ?)");
    // $stmt->bind_param("ss", $name, $file_path);
    // $stmt->execute();

    // Close the database connection
    $stmt->close();
    $conn->close();

    // // Display a success message to the user
    // echo "File uploaded successfully!";

} else {
    // Display an error message if the file upload failed
    echo "Error uploading file: " . $_FILES['file']['error'];
}
?>
