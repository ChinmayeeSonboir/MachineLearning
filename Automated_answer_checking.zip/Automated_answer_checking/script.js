const welcomeText = document.getElementById('welcome-text');
const text = 'Fast, Reliable and Automated.';
let i = 0;

function printText() {
  if (i < text.length) {
    welcomeText.innerHTML += text.charAt(i);
    i++;
    setTimeout(printText, 100); // adjust the delay time to change the typing speed
  }
}
printText();

function isElementInViewport(el) {
  var rect = el.getBoundingClientRect();
  return (
    rect.top >= 0 &&
    rect.left >= 0 &&
    rect.bottom <= (window.innerHeight || document.documentElement.clientHeight) &&
    rect.right <= (window.innerWidth || document.documentElement.clientWidth)
  );
}

var slideInLeft = document.querySelector('.slide-in-left');

window.addEventListener('scroll', function(event) {
  if (isElementInViewport(slideInLeft)) {
    slideInLeft.classList.add('slide-in-left');
  }
});




