<?php
// Connect to the SQL database
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "teacher";
$conn = new mysqli($servername, $username, $password, $dbname);

// Retrieve the key and username from the form data
$key = $_POST['key'];
$username = $_POST['username'];

// Check if the key exists in the key_table
$sql = "SELECT COUNT(*) as count FROM key_table WHERE key_name = '".$key."'";
$result = $conn->query($sql);
$row = $result->fetch_assoc();
$count = $row["count"];

if ($count == 0) {
    echo "Invalid key entered!";
} else {
// Select the key_students table and retrieve the file path
$sql = "SELECT paper FROM ".$key."_students WHERE name = '".$username."'";
$result = $conn->query($sql);
$row = $result->fetch_assoc();
$file_path = $row["paper"];

// Select the key_table and retrieve the table name
$sql = "SELECT * FROM key_table WHERE key_name = '".$key."'";
$result = $conn->query($sql);
$row = $result->fetch_assoc();
$table_name = $row["table_name"];

// Export the MySQL table to a CSV file
$filename = $table_name . ".csv";
$fp = fopen('php://output', 'w');
$query = "SELECT * FROM ".$table_name;
$result = $conn->query($query);
while ($row = $result->fetch_assoc()) {
    fputcsv($fp, $row);
}
fclose($fp);

// Execute a Python function with the CSV file and the retrieved file
$command = escapeshellcmd('python my_script.py '.$filename.' '.$file_path);
$output = shell_exec($command);
}

// Close the database connection
$conn->close();
?>
