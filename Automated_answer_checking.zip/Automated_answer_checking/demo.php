<?php
// Connect to the database
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "teacher";
$conn = new mysqli($servername, $username, $password, $dbname);

// Set the name of the table to convert to CSV
$table_name = "science";

// Set the path and name of the CSV file to create
$csv_file = __DIR__ . "/uploads/$table_name.csv";

// Generate the SELECT INTO OUTFILE statement
$sql = "SELECT * INTO OUTFILE '$csv_file'
        FIELDS TERMINATED BY ',' 
        ENCLOSED BY '\"'
        ESCAPED BY '\\\\'
        LINES TERMINATED BY '\\n'
        FROM $table_name";

// Execute the statement
$result = $conn->query($sql);

// Check if the query was successful
if ($result === TRUE) {
    echo "Table $table_name converted to CSV successfully.";
} else {
    echo "Error converting table $table_name to CSV: " . $conn->error;
}

// Close the database connection
$conn->close();
?>