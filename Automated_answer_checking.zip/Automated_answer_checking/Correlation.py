actual_marks = np.array([90, 80, 85, 95, 75])
# Assuming you have the similarity_scores and actual_marks in your DataFrame a_df
# similarity_scores should be calculated using the SentenceTransformer as shown before
# actual_marks should be the ground truth marks given by human graders
# Check for constant values in the arrays
is_marks_scored_constant = len(np.unique(marks_scored)) == 1
is_actual_marks_constant = len(np.unique(actual_marks)) == 1

# Print the result
print("Is marks_scored array constant?", is_marks_scored_constant)
print("Is actual_marks array constant?", is_actual_marks_constant)
# Create a DataFrame to store the sample data
aa_df = pd.DataFrame({
    'similarity_scores': similarity_scores,
    'marks-scored': marks_scored
})


# Calculate Pearson correlation
pearson_corr, _ = pearsonr(aa_df['marks-scored'][:len(actual_marks)],actual_marks)

# Calculate Spearman correlation
spearman_corr, _ = spearmanr(aa_df['marks-scored'][:len(actual_marks)],actual_marks)

# Print correlation coefficients
print("Pearson correlation coefficient:", pearson_corr)
print("Spearman correlation coefficient:", spearman_corr)

# Create a scatter plot to visualize the correlation
plt.figure(figsize=(8, 6))
plt.scatter(aa_df['marks-scored'][:len(actual_marks)], actual_marks, s=50, alpha=0.6)
plt.xlabel('Marks-scored')
plt.ylabel('Actual Marks')
plt.title('Marks-scored vs. Actual Marks')
plt.grid(True)
plt.show()