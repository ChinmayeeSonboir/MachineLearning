import os
from PIL import Image
from pdf2image import convert_from_path
import pytesseract

# Replace 'path/to/your/poppler/bin' with the actual full path to the Poppler bin directory
poppler_path = r"C:\Users\mohit\Downloads\Release-21.09.0\poppler-21.09.0\Library\bin"

filePath = 'this.pdf'
doc = convert_from_path(filePath, poppler_path=poppler_path)

path, fileName = os.path.split(filePath)
fileBaseName, fileExtension = os.path.splitext(fileName)

for page_number, page_data in enumerate(doc):
    txt = pytesseract.image_to_string(Image.fromarray(page_data)).encode("utf-8")
    print("Page # {} - {}".format(str(page_number), txt))
