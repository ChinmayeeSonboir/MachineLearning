from transformers import pipeline
import warnings
import pandas as pd

df=pd.read_csv("EnglishKey.csv")
answers=df['answers'].tolist()

# Suppress the UserWarning related to the pretrained model configuration modification
warnings.filterwarnings("ignore", category=UserWarning, message="You have modified the pretrained model configuration to control generation.*")

# # Suppress all warnings
# warnings.filterwarnings("ignore")

# Load a pre-trained GPT-2 model
generator = pipeline('text-generation', model='gpt2')

for i in range(7): 
    print(i+1)
    # Student's answer as input text
    student_answer = answers[i]

    # Summarize the student_answer into about 100 words
    summarized_answer = student_answer[:100]

    # Prompt to generate a brief summary using the summarized answer
    prompt = f"Expansion on the answer: {summarized_answer}"
    print(i+1)
    # Generate a brief summary using the model
    generated_summary = generator(prompt, max_length=500, num_return_sequences=1)
    print(i+1)
    # Initialize a variable to store the generated text 
    full_text = ""
 
    # Present the generated brief summary
    for summary in generated_summary:
        generated_text = summary['generated_text']

        # Check if the last full stop is present in the generated text
        last_full_stop_index = generated_text.rfind('.')
        if last_full_stop_index != -1:
            # Include the generated text up to the last full stop
            full_text = generated_text[:last_full_stop_index + 1]
            break

    # Print the generated text without the prompt content
    print(full_text)

