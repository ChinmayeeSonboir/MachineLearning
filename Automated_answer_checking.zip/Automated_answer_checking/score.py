# #use this library to install packages in code instead of command line
# import subprocess
# # List of libraries to install
# libraries = ['sentence-transformers', 'numpy', 'pandas', 'language-tool-python', 'matplotlib', 'seaborn', 'nltk']
# # Install each library using pip
# for library in libraries:
#     subprocess.check_call(["pip", "install", library])

# importing all the libraries needed
from sentence_transformers import SentenceTransformer, util
import numpy as np
import pandas as pd
import csv
import language_tool_python
import matplotlib.pyplot as plt
import seaborn as sns
import nltk
from nltk.tokenize import sent_tokenize, word_tokenize
from nltk.corpus import stopwords
from transformers import pipeline
import warnings

# Suppress the UserWarning related to the pretrained model configuration modification
warnings.filterwarnings("ignore", category=UserWarning, message="You have modified the pretrained model configuration to control generation.*")

# Set input file path
# input_file = 'student_papers.csv'  # This is the file uploaded by the teacher
import sys

input_file=sys.argv[1]

# Read CSV file using pandas
df = pd.read_csv(input_file)

# Get answer column as a list
answers = df['answers'].tolist()

# Get the total number of answers in the file
num_ans = df['answers'].shape[0]

# Here input.txt is users file, we are coverting it to a_input.txt file to have a format that can be properly converted to our a_output.csv
# Open input file and output file
with open(sys.argv[2], 'r') as input_file, open('a_input.txt', 'w') as output_file:
    previous_line_start = None
    # Loop through each line in the input file
    for line in input_file:
        # If the line is empty or only contains whitespace, skip the line
        if not line.strip():
            continue
        # If the line starts with a digit followed by a ')', it's the start of a new question
        if line[0].isdigit() and line[1] == ')':
            previous_line_start = line.strip()
            output_file.write('\n' + previous_line_start)
        # If the previous line was the start of a new question, and the current line is not the start of a new question
        elif previous_line_start is not None:
            # If the current line doesn't start with a digit, it's part of the answer
            if not line[0].isdigit() or (line[0].isdigit() and line[1] != ')'):
                output_file.write(line.strip())
                previous_line_start = None
            # If the current line starts with a digit followed by a ')', it's the start of a new question
            else:
                output_file.write('\n' + line.strip())
                previous_line_start = line.strip()
        # If the previous line was not the start of a new question, just write the line to the output file
        else:
            output_file.write(line)


# Open input and output files
# Set input and output file paths
a_input_file = 'a_input.txt'
a_output_file = 'a_output.csv'

# Open input and output files
with open(a_input_file, 'r') as f_in, open(a_output_file, 'w', newline='') as f_out:
    # Sort the lines by the first number
    lines = sorted(f_in.readlines(), key=lambda x: int(
        x.split(')')[0]) if x.strip() else float('inf'))

    # Set up CSV writer with column names
    writer = csv.writer(f_out)
    writer.writerow(['number', 'a_answers', 'questions', 'T_marks'])

    # Initialize variable for expected number
    expected_num = 1

    # Loop through sorted lines in input file
    for line in lines:
        # Split line by number and answer text
        parts = line.split(')', maxsplit=1)

        # If line starts with a number followed by a ')' and some text
        if len(parts) == 2 and parts[0].isdigit():
            num = int(parts[0])
            # Check if number is within range
            if num <= num_ans:
                # Write empty strings for any skipped numbers
                while expected_num < num:
                    writer.writerow([str(expected_num), ''])
                    expected_num += 1
                # Write number and answer text to CSV file
                writer.writerow([parts[0], parts[1].strip(), ''])
                expected_num += 1

    # Write empty strings for any remaining numbers
    while expected_num <= len(df):
        writer.writerow([str(expected_num), ''])
        expected_num += 1

# reading the output file using pandas
a_df = pd.read_csv('a_output.csv', keep_default_na=False)

# Copy the question table from student_papers file a_output file
a_df['questions'] = df['questions']

a_answers = a_df['a_answers'].tolist()

# Copy the marks table from student_papers file a_output file
a_df['T_marks'] = df['marks']

# This is to put the question column before answer in a_output file
a_df[['a_answers', 'questions']] = a_df[['questions', 'a_answers']]
a_df.rename(columns={'a_answers': 'question'}, inplace=True)
a_df.rename(columns={'questions': 'a_answers'}, inplace=True)

# Write the updated a_output file
a_df.to_csv('a_output.csv', index=False)

# training the model
model = SentenceTransformer('stsb-roberta-large')

# Create a list to store similarity scores
similarity_scores = []

for i in range(num_ans):
    sen1 = answers[i]  # ans from modal answer paper
    sen2 = a_answers[i]  # ans from student paper

    # Encode sentences
    emb1 = model.encode(sen1, convert_to_tensor=True)
    emb2 = model.encode(sen2, convert_to_tensor=True)

    # Calculate cosine similarity score
    cosine_scores = util.pytorch_cos_sim(emb1, emb2)

    # Store the similarity score in the list
    similarity_scores.append(cosine_scores.item())

    print(f"Similarity score of {i+1} answer:", cosine_scores.item())

# Add the similarity scores as a new column to the a_df DataFrame
a_df['similarity_scores'] = similarity_scores
# Save the updated DataFrame to a CSV file
a_df.to_csv('a_output.csv', index=False)

# Iterating through each row and computing the marks scored based on the similarity found
for i in range(num_ans):
    similarity_score = a_df.loc[i, 'similarity_scores']
    marks = a_df.loc[i, 'T_marks']

    # Compute the marks-scored based on the similarity score and the marks
    if similarity_score >= 0.9:
        marks_scored = marks
    elif similarity_score >= 0.8:
        marks_scored = marks * 0.95
    elif similarity_score >= 0.75:
        marks_scored = marks * 0.85
    elif similarity_score >= 0.7:
        marks_scored = marks * 0.8
    elif similarity_score >= 0.65:
        marks_scored = marks * 0.7
    elif similarity_score >= 0.6:
        marks_scored = marks * 0.5
    elif similarity_score >= 0.5:
        marks_scored = marks * 0.3
    else:
        marks_scored = 0

    # Set the value of the marks-scored column in the same row
    a_df.loc[i, 'marks-scored'] = marks_scored

# Save the updated DataFrame to a CSV file
a_df.to_csv('a_output.csv', index=False)

# Sum all row entries for each column
t_sums = df['marks'].sum()
sums = a_df['marks-scored'].sum()

# Print sums for each column
print(f"Total marks scored are {sums} out of {t_sums}")

tool = language_tool_python.LanguageTool('en-US')

# iterate over the answers and check for grammatical errors
for i in range(num_ans):
    text = a_answers[i]

    # check for errors using LanguageTool
    matches = tool.check(text)

    # print error report for the current answer
    print(f"\nGrammatical errors in answer {i+1}:")
    if not matches:
        print("No grammatical errors found.")
    else:
        print(f"\nTotal number of errors found: {len(matches)}")
        print(f"\nOriginal text: {text}")
        for j, match in enumerate(matches, 1):
            print(f"\nError {j}:")
            print(f"Description: {match.message}")
            print(f"Suggested correction: {', '.join(match.replacements)}")
            print(f"Context: {match.context}\n")

    # Load a pre-trained GPT-2 model
    generator = pipeline('text-generation', model='gpt2')

    # Student's answer as input text
    student_answer = answers[i]
    # Summarize the student_answer into about 100 words
    summarized_answer = student_answer[:100]

    print("\nMore about the topic:\n")

    # Prompt to generate a brief summary using the summarized answer
    prompt = f"Expansion on the answer: {summarized_answer}"

    # Generate a brief summary using the model
    generated_summary = generator(prompt, max_length=150, num_return_sequences=1)

    # Initialize a variable to store the generated text
    full_text = ""

    # Present the generated brief summary  
    for summary in generated_summary:
        generated_text = summary['generated_text']

        # Check if the last full stop is present in the generated text
        last_full_stop_index = generated_text.rfind('.')
        if last_full_stop_index != -1:
            # Include the generated text up to the last full stop
            full_text = generated_text[:last_full_stop_index + 1]
            break

    # Print the generated text without the prompt content
    print(full_text)        

# # download stopwords
# nltk.download('stopwords')

# download grammar tool
tool = language_tool_python.LanguageTool('en-US')

grammar_error_count = 0
spelling_error_count = 0
total_word_count = 0
total_sentences = 0

# input text
for i in range(num_ans):
    text = a_answers[i]

    # split text into sentences
    sentences = sent_tokenize(text)

    # set up stop words
    stop_words = set(stopwords.words('english'))

    # initialize variables
    total_sentences += len(sentences)

    for sentence in sentences:
        # check grammar errors
        matches = tool.check(sentence)
        if len(matches) > 0:
            grammar_error_count += 1

        # check spelling errors
        words = word_tokenize(sentence)
        word_count = len(words)
        total_word_count += word_count
        for word in words:
            if word.lower() not in stop_words and not word.isnumeric() and not word.isalpha():
                spelling_error_count += 1

# calculate percentage errors
if total_sentences == 0:
    grammar_error_percent = 0
else:
    grammar_error_percent = (grammar_error_count / total_sentences) * 100

if total_word_count == 0:
    spelling_error_percent = 0
else:
    spelling_error_percent = (spelling_error_count / total_word_count) * 100

print("Total Sentences:", total_sentences)
print("Grammar Error Percentage:", grammar_error_percent)
print("Spelling Error Percentage:", spelling_error_percent)

# labels = ['Grammatical Errors', 'Spelling Errors', 'Correctly Written Sentences']
# sizes = [grammar_error_percent, spelling_error_percent, 100-grammar_error_percent-spelling_error_percent]
# colors = ['yellowgreen', 'lightcoral', 'gold']

# sns.set_style("whitegrid")
# plt.figure(figsize=(6,6))
# plt.pie(sizes, colors=colors, labels=labels, autopct='%1.1f%%', startangle=90, textprops={'fontsize': 14})

# plt.title("Error Percentage in Text", fontsize=16)
# plt.axis('equal')
# plt.show()


#Calculating model's accuracy

# Sample model and human grades as numpy arrays
model_grades = marks_scored
human_grades = np.array([4, 3, 2, 4, 3,4])

# Mean Absolute Error (MAE)
mae = np.mean(np.abs(model_grades - human_grades))
print("Mean Absolute Error (MAE):", mae)

# Root Mean Square Error (RMSE)
rmse = np.sqrt(np.mean((model_grades - human_grades)**2))
print("Root Mean Square Error (RMSE):", rmse)

# Percentage Agreement

# Set the threshold for agreement (e.g., 5 points)
threshold = 1

# Calculate the absolute difference between model and human grades
absolute_differences = np.abs(model_grades - human_grades)

# Create an array of 1s and 0s based on whether the difference is within the threshold
agreement_indicator = (absolute_differences <= threshold).astype(int)

# Calculate the percentage of cases where there is agreement (1)
percentage_agreement = (np.sum(agreement_indicator == 1) / len(agreement_indicator)) * 100

print("Agreement Indicator (1 for agreement, 0 for disagreement):", agreement_indicator)
print("Percentage Agreement:", percentage_agreement, "%")

