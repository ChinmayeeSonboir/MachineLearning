<?php
// Get the database key and CSV file from the form submission
$key = $_POST['key'];
$csv = $_FILES['csv']['tmp_name'];

// Save the CSV file to the uploads directory with the name of the key
$upload_dir = __DIR__ . '/uploads/';
$csv_filename = $upload_dir . $key . '.csv';
move_uploaded_file($csv, $csv_filename);


// Connect to the MySQL server and select the database
$host = 'localhost';  // Replace with your MySQL server address
$user = 'root';  // Replace with your MySQL username
$pass = '';  // Replace with your MySQL password
$dbname = 'teacher'; // Replace with your database name
$conn = mysqli_connect($host, $user, $pass, $dbname);

// Check if the connection was successful
if (!$conn) {
	die('Could not connect to MySQL: ' . mysqli_connect_error());
}

// // Check if the table already exists
$table_name = $key;  // Replace with the name of the table you want to create
// $sql_check_table_exists = "SELECT 1 FROM $table_name LIMIT 1";
// $result = mysqli_query($conn, $sql_check_table_exists);

// if ($result !== false) {
//     echo "The key is already been assigned, please choose a different key value.<br>";
//     // You may want to add additional handling here, such as displaying an error message or redirecting the user
//     exit();
// }

// Create the table with the given key
$sql = "CREATE TABLE $table_name (question VARCHAR(2000), answer VARCHAR(2000), marks INT(30))";

if (mysqli_query($conn, $sql)) {
    echo "Table created successfully with key $key<br>";
    
    // Create the key_student table for this key
    $key_student_table_name = $key."_students";
    $sql_key_student = "CREATE TABLE $key_student_table_name (name VARCHAR(200), paper LONGTEXT)";
    
    if(mysqli_query($conn, $sql_key_student)) {
        echo "Table created successfully for students with key $key<br>";
    } else {
        echo "Error creating table for students: " . mysqli_error($conn) . "<br>";
    }
} else {
    echo "Error creating table: " . mysqli_error($conn) . "<br>";
}

// Import the CSV file into the table
if (($handle = fopen("uploads/" . $key . ".csv", "r")) !== FALSE)  {
    // Prepare the SQL statement
    $stmt = mysqli_prepare($conn, "INSERT INTO $table_name (question, answer, marks) VALUES (?, ?, ?)");
    mysqli_stmt_bind_param($stmt, 'sss', $question, $answer, $marks);

    $counter = 0;  // Initialize the counter variable

    while (($data = fgetcsv($handle, 1000, ",")) !== FALSE) {
        // Skip the first row
        if ($counter == 0) {
            $counter++;
            continue;
        }

        // Get the values from the CSV file
        $question = $data[0];
        $answer = $data[1];
        $marks = $data[2];

        // Execute the prepared statement
        if (mysqli_stmt_execute($stmt)) {
            echo "Data imported successfully<br>";
        } else {
            echo "Error importing data: " . mysqli_error($conn) . "<br>";
        }
    }
    fclose($handle);
}
